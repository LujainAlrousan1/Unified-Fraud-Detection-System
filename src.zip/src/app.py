from flask import Flask, request, jsonify, render_template
import re
import logging
import numpy as np
import pandas as pd
import joblib
import tensorflow as tf
from pathlib import Path
import os

app = Flask(__name__, static_folder='static', template_folder='templates')
logging.basicConfig(level=logging.INFO)

MODELS_DIR = Path(__file__).parent / "models"
try:
    logging.info("Loading models...")
    dl_model = tf.keras.models.load_model(str(MODELS_DIR / "DL_model_fixed.keras"))
    rf_model = joblib.load(str(MODELS_DIR / "random_forest_model.pkl"))
    blending_model = joblib.load(str(MODELS_DIR / "blending_model.pkl"))
    cyber_encoders = joblib.load(str(MODELS_DIR / "cyber_encoders.pkl"))
    logging.info("Models loaded successfully!")
except Exception as e:
    logging.error(f"Error loading models: {str(e)}")
    dl_model = rf_model = blending_model = cyber_encoders = None

def prepare_features(amount, ip, cc_data=None, cyber_data=None):
    """Prepare integrated features for both models"""
    
    if cc_data is None:
        cc_data = {f'v{i}': 0.0 for i in range(1, 30)}
    
    
    if cyber_data is None:
        ip_parts = list(map(int, ip.split('.'))) if ip.count('.') == 3 else [0,0,0,0]
        cyber_data = {
            'ip_numeric': sum(ip_parts),
            'network_packet_size': 0.45,
            'failed_logins': 0.1
        }
    
    
    if cyber_encoders:
        for col in cyber_encoders:
            if col in cyber_data:
                try:
                    cyber_data[col] = cyber_encoders[col].transform([str(cyber_data[col])])[0]
                except:
                    cyber_data[col] = 0
    
    return {
        'financial': np.array([[amount] + list(cc_data.values())]).astype(np.float32),
        'cyber': pd.DataFrame([cyber_data]).values.astype(np.float32)
    }

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/health')
def health_check():
    return jsonify({
        "status": "running",
        "models_loaded": bool(dl_model and rf_model and blending_model)
    })

@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.json
        
        
        if 'amount' not in data or 'ip' not in data:
            return jsonify({"status": "error", "message": "Amount and IP are required"}), 400
        
        try:
            amount = float(data['amount'])
            if amount <= 0:
                raise ValueError
        except ValueError:
            return jsonify({"status": "error", "message": "Invalid amount"}), 400

        if not re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$', data['ip']):
            return jsonify({"status": "error", "message": "Invalid IP format"}), 400

      
        features = prepare_features(
            amount=data['amount'],
            ip=data['ip'],
            cc_data=data.get('cc_features'),
            cyber_data=data.get('cyber_features')
        )

        
        dl_pred = float(dl_model.predict(features['financial'])[0][0])
        rf_pred = float(rf_model.predict_proba(features['cyber'])[0][1])
        final_pred = float(blending_model.predict_proba([[dl_pred, rf_pred]])[0][1])

        return jsonify({
            "status": "success",
            "prediction": "Legitimate" if final_pred <= 0.5 else "Fraudulent",
            "confidence": round(final_pred * 100, 2),
            "details": {
                "amount": amount,
                "ip": data['ip'],
                "dl_score": round(dl_pred * 100, 2),
                "rf_score": round(rf_pred * 100, 2),
                "features_used": {
                    "financial": features['financial'].shape[1],
                    "cyber": features['cyber'].shape[1]
                }
            }
        })

    except Exception as e:
        logging.error(f"Error: {str(e)}", exc_info=True)
        return jsonify({
            "status": "error",
            "message": "Processing error",
            "details": str(e)
        }), 500

@app.route('/results')
def results():
    return render_template('results.html',
                         prediction=request.args.get('prediction', 'Legitimate'),
                         confidence=request.args.get('confidence', '0'),
                         amount=request.args.get('amount', '0'),
                         ip=request.args.get('ip', '0.0.0.0'),
                         dl_score=request.args.get('dl_score', '0'),
                         rf_score=request.args.get('rf_score', '0'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)