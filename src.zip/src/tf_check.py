import cpuinfo
import tensorflow as tf
import subprocess
import sys

def check_system():
    print("\n" + "="*50)
    print("System Check Started")
    print("="*50)
    
    
    try:
        cpu_info = cpuinfo.get_cpu_info()
        avx_supported = 'avx' in cpu_info['flags']
        print(f"\nAVX Supported (CPU): {avx_supported}")
        print(f"CPU Model: {cpu_info['brand_raw']}")
    except Exception as e:
        print(f"\n❌ CPU Check Failed: {str(e)}")
        avx_supported = False

    
    tf_ok = False
    try:
        print("\n" + "-"*50)
        print("TensorFlow Check")
        print("-"*50)
        
        print(f"\nTensorFlow Version: {tf.__version__}")
        
       
        compile_flags = tf.sysconfig.get_compile_flags()
        print("\nCompile Flags:", compile_flags)
        
        
        print("\nTesting TensorFlow Operations:")
        tf.debugging.set_log_device_placement(True)
        a = tf.constant([1.0, 2.0, 3.0])
        b = a * 2
        print("Result:", b.numpy())
        
        tf_ok = True
        
    except Exception as e:
        print(f"\n❌ TensorFlow Check Failed: {str(e)}")

   
    print("\n" + "="*50)
    print("Final Result:")
    print(f"- AVX Support: {'✅' if avx_supported else '❌'}")
    print(f"- TensorFlow Works: {'✅' if tf_ok else '❌'}")
    print("="*50 + "\n")

if __name__ == "__main__":
    check_system()